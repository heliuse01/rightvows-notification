<?php

$config['apikey'] = '8Wd1jg18RfrJjkchvEpQCJ9J1_Y1-9xb60oS-Wd3j0Url';  // https://killbot.org/dashboard/developers