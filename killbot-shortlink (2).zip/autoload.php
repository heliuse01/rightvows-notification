<?php
error_reporting(0);
require_once('killbot.php');
require_once('config.php');

$Killbot = new Killbot;